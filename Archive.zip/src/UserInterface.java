
/**
 * @author 
 */
public interface UserInterface {
    /**
     * Callback function for receiving updates to the state of the game.
     */
    public void handleStateUpdate(GameState2 newState);

    /**
     * Causes the user interface to prompt the user for the agents and names for
     * the players and constructs/returns new instances of the prescribed
     * players.
     */
    public CheckersPlayer[] getPlayers();

    /**
     * Assigns the agents that will be playing the current game.
     */
    public void setPlayers(CheckersPlayer player1, CheckersPlayer player2);

    /**
     * Callback function for updating the amount of time that remains before a
     * player's deadline.
     * @param secondsRemaining The amount of time in seconds before the end of
     *            <code>player</code>'s deadline. A negative value indicates
     *            that the player has an infinite deadline.
     */
    public void updateTimeRemaining(CheckersPlayer player, int secondsRemaining);

    /**
     * Callback function for updating the total amount of time (in milliseconds)
     * a player has used thus far in the game.
     */
    public void updateTimeUsed(CheckersPlayer player, long millisUsed);

    public void log(String str, Object o);
}
