
public class Move {
    Square from;
    Square to;
    GameState2.Player player;

    public Move(Square from, Square to, GameState2.Player player) {
        this.from = from;
        this.to = to;
        this.player = player;

    }

    public GameState2.Player getPlayer() {
        return player;
    }

    public void setPlayer(GameState2.Player player) {
        this.player = player;
    }

    public Square getFrom() {
        return this.from;
    }

    public Square getTo() {
        return this.to;
    }

    public int colDist() {
        return to.col - from.col;
    }

    public int rowDist() {
        return to.row - from.row;
    }

}
